Should match the structure of Foundry's `reasources/app/templates`.
